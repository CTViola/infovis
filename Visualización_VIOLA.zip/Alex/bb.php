<?php
  
$conexion = pg_connect ("host=localhost dbname=Alex user=postgres password=postgres");

$consulta = pg_query($conexion, "select count (*) as Cantidad, fecha, actividad from jardin inner join accion on id_dia = fk_jardin inner join actividad_cantidad on id_actividad_cantidad = fk_actividad_cantidad group by fecha, actividad order by fecha");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alexander 2</title>
</head>

<body>

 <h1> Representación acumulada de acciones por día </h1>
    <style>
       
      h1{text-decoration: underline; text-align:center; margin-top:5%}
      
        #chartdiv {
          margin-top:5%;
          width: 100%;
          height: 500px;
        }
        </style>
        
        <!-- Resources -->
        <script src="https://cdn.amcharts.com/lib/5/index.js"></script>
        <script src="https://cdn.amcharts.com/lib/5/xy.js"></script>
        <script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>
        
        <!-- Chart code -->
        <script>
        am5.ready(function() {
        
        // Create root element
        // https://www.amcharts.com/docs/v5/getting-started/#Root_element
        var root = am5.Root.new("chartdiv");
        
        
        // Set themes
        // https://www.amcharts.com/docs/v5/concepts/themes/
        root.setThemes([
          am5themes_Animated.new(root)
        ]);
        
        
        // Create chart
        // https://www.amcharts.com/docs/v5/charts/xy-chart/
        var chart = root.container.children.push(am5xy.XYChart.new(root, {
          panX: false,
          panY: false,
          wheelX: "panX",
          wheelY: "zoomX",
          layout: root.verticalLayout
        }));
        
        
        // Add legend
        // https://www.amcharts.com/docs/v5/charts/xy-chart/legend-xy-series/
        var legend = chart.children.push(am5.Legend.new(root, {
          centerX: am5.p50,
          x: am5.p50
        }));
        
        var data = [
          <?php
          $ultimo = "";
            while( $accion = pg_fetch_object($consulta) )
            {
               
                if ($ultimo != $accion->fecha)
                {
                 if ($ultimo != "")
                 {
                  echo "},";
                 }
                 echo "{fecha:'".$accion->fecha."'";
                 $ultimo = $accion->fecha;            
                }   
                echo ",".$accion->actividad.":".$accion->cantidad;           
            }
    
          ?>
         
        }, 
      
         ];
        
        
        // Create axes
        // https://www.amcharts.com/docs/v5/charts/xy-chart/axes/
        var xAxis = chart.xAxes.push(am5xy.CategoryAxis.new(root, {
          categoryField: "fecha",
          renderer: am5xy.AxisRendererX.new(root, {
            cellStartLocation: 0.1,
            cellEndLocation: 0.9
          }),
          tooltip: am5.Tooltip.new(root, {})
        }));
        
        xAxis.data.setAll(data);
        
        var yAxis = chart.yAxes.push(am5xy.ValueAxis.new(root, {
          min: 0,
          renderer: am5xy.AxisRendererY.new(root, {})
        }));
        
        
        // Add series
        // https://www.amcharts.com/docs/v5/charts/xy-chart/series/
        function makeSeries(name, fieldName, stacked) {
          var series = chart.series.push(am5xy.ColumnSeries.new(root, {
            stacked: stacked,
            name: name,
            xAxis: xAxis,
            yAxis: yAxis,
            valueYField: fieldName,
            categoryXField: "fecha"
          }));
        
          series.columns.template.setAll({
            tooltipText: "{name}, {categoryX}:{valueY}",
            width: am5.percent(90),
            tooltipY: am5.percent(10)
          });
          series.data.setAll(data);
        
          // Make stuff animate on load
          // https://www.amcharts.com/docs/v5/concepts/animations/
          series.appear();
        
          series.bullets.push(function () {
            return am5.Bullet.new(root, {
              locationY: 0.5,
              sprite: am5.Label.new(root, {
                text: "{valueY}",
                fill: root.interfaceColors.get("alternativeText"),
                centerY: am5.percent(50),
                centerX: am5.percent(50),
                populateText: true
              })
            });
          });
        
          legend.data.push(series);
        }
        
        makeSeries("Pis", "pis", true);
        makeSeries("Popo", "caca", true);
        makeSeries("Siesta", "siesta", true);
        makeSeries("Leche", "leche", true);
       
        
        
        // Make stuff animate on load
        // https://www.amcharts.com/docs/v5/concepts/animations/
        chart.appear(1000, 100);
        
        }); // end am5.ready()
        </script>
        
        <!-- HTML -->
        <div id="chartdiv"></div>
     
<!-- Styles -->
        
</body>
</html>