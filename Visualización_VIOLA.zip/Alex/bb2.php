<?php
  
$conexion = pg_connect ("host=localhost dbname=Alex user=postgres password=postgres");

$consulta = pg_query($conexion, "select count (*), actividad from accion inner join actividad_cantidad on id_actividad_cantidad = fk_actividad_cantidad group by actividad");

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aexander 1</title>
</head>
<body>

<h1> Porcentage de acciones realizadas en el mes </h1>
  <!-- Styles -->
<style>

h1{text-decoration: underline; text-align:center; margin-top:5%}
    #chartdiv2 {
      margin-top:5%;
      width: 100%;
      height: 500px;
    }
    </style>
    
    <!-- Resources -->
    <script src="https://cdn.amcharts.com/lib/5/index.js"></script>
    <script src="https://cdn.amcharts.com/lib/5/percent.js"></script>
    <script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>
    
    <!-- Chart code -->
    <script>
    am5.ready(function() {
    
    // Create root2 element
    // https://www.amcharts.com/docs/v5/getting-started/#Root_element
    var root2 = am5.Root.new("chartdiv2");
    
    // Set themes
    // https://www.amcharts.com/docs/v5/concepts/themes/
    root2.setThemes([
      am5themes_Animated.new(root2)
    ]);
    
    // Create chart2
    // https://www.amcharts.com/docs/v5/charts/percent-charts/pie-chart2/
    var chart2 = root2.container.children.push(am5percent.PieChart.new(root2, {
      radius: am5.percent(90),
      innerRadius: am5.percent(50),
      layout: root2.horizontalLayout
    }));
    
    // Create series
    // https://www.amcharts.com/docs/v5/charts/percent-charts/pie-chart2/#Series
    var series2 = chart2.series.push(am5percent.PieSeries.new(root2, {
      name: "Series",
      valueField: "count",
      categoryField: "actividad"
    }));
    
    // Set data
    // https://www.amcharts.com/docs/v5/charts/percent-charts/pie-chart2/#Setting_data
    
    series2.data.setAll([ 
    <?php
         
         while( $accion = pg_fetch_object($consulta) ){
          echo "{"; 
            echo "count:".$accion->count.",actividad:'".$accion->actividad."'";
            echo "},";
          }

    ?>

    ]);
    
    // Disabling labels and ticks
    series2.labels.template.set("visible", false);
    series2.ticks.template.set("visible", false);
    
    // Adding gradients
    series2.slices.template.set("strokeOpacity", 0);
    series2.slices.template.set("fillGradient", am5.RadialGradient.new(root2, {
      stops: [{
        brighten: -0.8
      }, {
        brighten: -0.8
      }, {
        brighten: -0.5
      }, {
        brighten: 0
      }, {
        brighten: -0.5
      }]
    }));
    
    // Create legend2
    // https://www.amcharts.com/docs/v5/charts/percent-charts/legend2-percent-series/
    var legend2 = chart2.children.push(am5.Legend.new(root2, {
      centerY: am5.percent(50),
      marginRight: 30, 
      fontSize: 30,
      y: am5.percent(50),
      marginTop: 25,
      marginBottom: 25,
      layout: root2.verticalLayout
    }));
    
    legend2.data.setAll(series2.dataItems);
    
    
    // Play initial series animation
    // https://www.amcharts.com/docs/v5/concepts/animations/#Animation_of_series
    series2.appear(1000, 100);
    
    }); // end am5.ready()
    </script>
    
    <!-- HTML -->
    <div id="chartdiv2"></div>
   

     
<!-- Styles -->
    
</body>
</html>